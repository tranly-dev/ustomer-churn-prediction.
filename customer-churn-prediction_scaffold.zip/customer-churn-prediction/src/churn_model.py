from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

PRO = Path('data/processed')

def main():
    feats_path = PRO/'features.csv'
    labels_path = PRO/'churn_labels.csv'
    if not feats_path.exists() or not labels_path.exists():
        print('Need features.csv and churn_labels.csv in data/processed/')
        return
    X = pd.read_csv(feats_path)
    y = pd.read_csv(labels_path)
    data = X.merge(y, on='customer_id', how='inner')
    y = data['churn'].astype(int)
    X = data.drop(columns=['churn'])
    cat_cols = [c for c in X.columns if X[c].dtype == 'object']
    pre = ColumnTransformer([('cat', OneHotEncoder(handle_unknown='ignore'), cat_cols)], remainder='passthrough')
    model = Pipeline([('prep', pre), ('clf', LogisticRegression(max_iter=200))])
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    model.fit(X_tr, y_tr)
    y_pred = model.predict(X_te)
    print(classification_report(y_te, y_pred))
    pd.DataFrame({'customer_id': X_te['customer_id'], 'pred': y_pred}).to_csv(PRO/'predictions.csv', index=False)
if __name__ == '__main__': main()
