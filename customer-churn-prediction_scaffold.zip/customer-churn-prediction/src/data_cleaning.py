import pandas as pd
from pathlib import Path

RAW = Path('data/raw')
PRO = Path('data/processed'); PRO.mkdir(parents=True, exist_ok=True)

def main():
    customers = pd.read_csv(RAW/'customers.csv') if (RAW/'customers.csv').exists() else pd.DataFrame()
    transactions = pd.read_csv(RAW/'transactions.csv') if (RAW/'transactions.csv').exists() else pd.DataFrame()
    if not customers.empty: customers.to_csv(PRO/'customers_clean.csv', index=False)
    if not transactions.empty: transactions.to_csv(PRO/'transactions_clean.csv', index=False)
    print('Data cleaning done.')
if __name__ == '__main__': main()
