import pandas as pd
from pathlib import Path
PRO = Path('data/processed'); PRO.mkdir(parents=True, exist_ok=True)

def main():
    cust = pd.read_csv(PRO/'customers_clean.csv') if (PRO/'customers_clean.csv').exists() else pd.DataFrame()
    trans = pd.read_csv(PRO/'transactions_clean.csv') if (PRO/'transactions_clean.csv').exists() else pd.DataFrame()
    if not trans.empty:
        agg = (trans.groupby('customer_id')
                     .agg(txn_count=('amount','count'), txn_sum=('amount','sum'))
                     .reset_index())
    else:
        agg = pd.DataFrame()
    feats = cust.merge(agg, on='customer_id', how='left') if not cust.empty else cust.copy()
    if not feats.empty: feats.fillna(0).to_csv(PRO/'features.csv', index=False)
    print('Feature engineering done.')
if __name__ == '__main__': main()
