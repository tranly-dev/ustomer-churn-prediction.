# 🧩 Customer Churn Prediction (Python, SQL, Power BI)

Dự án dự đoán **rời bỏ khách hàng (churn)** cho dịch vụ tài chính bằng **Python (pandas, scikit‑learn)**, kết hợp trích xuất dữ liệu bằng **SQL** và trực quan hoá **Power BI**.

## 🎯 Mục tiêu
- Làm sạch dữ liệu & EDA (phân tích khám phá).
- Tạo đặc trưng (feature engineering) cho mô hình.
- Huấn luyện **Logistic Regression** dự đoán churn.
- Dashboard Power BI theo dõi xu hướng churn theo nhóm khách hàng.

## 🧱 Cấu trúc thư mục
```
customer-churn-prediction
├─ data/
│  ├─ raw/          # dữ liệu gốc (CSV từ hệ thống)
│  └─ processed/    # dữ liệu đã làm sạch/biến đổi
├─ notebooks/
│  ├─ 01_EDA.ipynb  # phân tích khám phá
│  └─ 02_Model.ipynb# mô hình hoá
├─ reports/
│  ├─ churn_visualization.pbix  # Power BI (nếu có)
│  └─ churn_summary.md          # tóm tắt insight
├─ src/
│  ├─ data_cleaning.py
│  ├─ feature_engineering.py
│  └─ churn_model.py
├─ requirements.txt
└─ README.md
```

## ⚙️ Cách chạy (local)
```bash
python -m venv .venv
# Windows:
# .venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate

pip install -r requirements.txt

# Đặt dữ liệu vào data/raw/:
#  - customers.csv (thông tin KH, gồm customer_id)
#  - transactions.csv (giao dịch: customer_id, amount, date...)
#  - churn_labels.csv (customer_id, churn 0/1)
python src/data_cleaning.py
python src/feature_engineering.py
python src/churn_model.py
```
